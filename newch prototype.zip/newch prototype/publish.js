const publishButton = document.getElementById('submit-post');
const publishInput = document.getElementById('post-body');


// if the person presses enter, publish the post
publishInput.addEventListener('keyup', function(event) {
    if (event.which == 13) {
        publishPost();
    }
});

// if the person clicks the button, publish the post
publishButton.addEventListener('click', publishPost);

function publishPost() {
    const uid = fb.getUID();
    fb.publishPost(uid, publishInput.value);
    publishInput.value = ""; // reset textarea
}